from django.shortcuts import render,redirect
from .models import *
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
# Create your views here.

@login_required(login_url="/login/")
def recipes(request):
    if request.method == "POST": 
        data=request.POST
        recipe_img=request.FILES.get('Recipe_img') #ya img k liye alag scene hy
        recipe_name=data.get('Recipe_Name')
        recipe_desc=data.get('Recipe_desc')
        #for add in model => Receipe
        Recipe.objects.create(
            recipe_img=recipe_img,
            recipe_name=recipe_name,
            recipe_desc=recipe_desc
        )
        #for print on cmd
        #print(Recipe_Name)
        #print(Recipe_desc)
        #print(Recipe_img)
        return redirect("/recipes/")
    queryset=Recipe.objects.all()
    if request.GET.get('Search'):
        queryset=queryset.filter(recipe_name__icontains=request.GET.get('Search'))

    context={'recipes':queryset}
    return render(request,'recipe.html',context)

@login_required(login_url="/login/")
def delete_recipe(request,id):
    queryset=Recipe.objects.get(id=id)
    queryset.delete()
    return redirect('/recipes/')

@login_required(login_url="/login/")
def update_recipe(request,id):
    queryset=Recipe.objects.get(id=id)

    if request.method == "POST":
        data=request.POST
        # in teen line sy value get kri hy
        recipe_name=data.get('Recipe_name')
        recipe_desc=data.get('Recipe_desc')
        recipe_img=request.FILES.get('Recipe_img')
        
        # ab value ko show kraingy
        queryset.Recipe_name=recipe_name
        queryset.Recipe_desc=recipe_desc
        if recipe_img:  #agar image ho to show krwa do wrna ni
            queryset.Recipe_img=recipe_img
        queryset.save()
        return redirect('/recipes/')

    context={'recipe':queryset}
    return render(request,"update_recipe.html",context)  

def register(request):
    if request.method == "POST":
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password = request.POST.get('password')
        user=User.objects.filter(username=username)
        if user.exists():
            messages.info(request, "username os already exist.")
            return redirect('/register/')


# These print statements will help you see if the data 
# is being received correctly.
        # print(f"First Name: {first_name}")
        # print(f"Last Name: {last_name}")
        # print(f"Username: {username}")
        # print(f"Password: {password}")

        user = User.objects.create(
            first_name=first_name,
            last_name=last_name,
            username=username
        )
        user.set_password(password)
        user.save()
        messages.info(request, "account created.")

        return redirect('/register/')

    return render(request, "register.html")

def login_page(request):
    if request.method=="POST":
        username=request.POST.get('username')
        password=request.POST.get('password')
        if not User.objects.filter(username=username).exists():
            messages.error(request,"username is valid")
        user=authenticate(username=username,password=password)

        if user is None:
            messages.error(request,"invalid password")
            return redirect('/login/')
        else:
            login(request,user)
            return redirect('/recipes/')
    return render(request,"login.html")

@login_required(login_url="/login/")
def logout_page(request):
    logout(request)
    return redirect('/login/')
from django.db.models import Q,Sum

def get_student(request):
    queryset=Student.objects.all()

    if request.GET.get('search'):
        search=request.GET.get('search')
        queryset=queryset.filter(
            Q(student_name__icontains = search ) |
            Q(department__department__icontains = search )|
            Q(student_id__student_id__icontains = search )
            )

    paginator = Paginator(queryset, 10)  # Show 25 contacts per page.

    page_number = request.GET.get("page",1)
    page_obj = paginator.get_page(page_number)
    # return render(request, "list.html", {"page_obj": page_obj})

    return render(request,'report/student.html',{'queryset':page_obj})

def show_marks(request,student_id):
    queryset=Subject_mark.objects.filter(student__student_id__student_id=student_id)
    total_marks=queryset.aggregate(total_marks=Sum('marks'))
    return render(request,'report/see_marks.html',{'queryset':queryset,'total_marks':total_marks})
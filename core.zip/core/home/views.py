from django.shortcuts import render,HttpResponse
student=[
    {'name':'hammad','age':23},
    {'name':'handy','age':3},
    {'name':'hami','age':2},
    {'name':'hary','age':33},
]
text=[
    """        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora magnam eum necessitatibus asperiores veniam ipsum nobis amet, illo eos esse distinctio minima et tenetur optio, atque totam nesciunt? Accusamus, tempore corrupti facere provident quis reiciendis minus atque perferendis ad ut enim rerum aperiam porro voluptas hic cumque officiis accusantium tempora modi sed delectus id saepe cum! Quod harum, nostrum nulla voluptatum, suscipit, aspernatur eum maxime veniam cum dignissimos maiores delectus in omnis similique amet. Qui eveniet veniam maiores, eum in voluptatum consequatur libero. Veritatis nesciunt deserunt neque ut doloribus culpa recusandae vero, ratione deleniti architecto nam laborum, omnis eveniet eligendi adipisci voluptatum facilis aut. Quia voluptates in soluta laudantium maxime, rem cumque nobis. Quis voluptatum, nemo voluptas quia, veniam in omnis, totam officiis blanditiis nobis ratione? Neque consectetur quia eius! Repudiandae modi distinctio laborum suscipit dignissimos asperiores corrupti doloremque beatae voluptatem. Consequuntur debitis explicabo perspiciatis voluptatem quas, quod blanditiis cupiditate dignissimos, reiciendis a magnam odio aliquid mollitia soluta ea accusamus tempore adipisci eaque alias. Quas veniam, quibusdam autem voluptatem temporibus aliquam dolor quo assumenda velit harum molestias laborum distinctio ex impedit? Quibusdam ad, ullam facere magnam omnis in quos possimus exercitationem aspernatur, sit quae! Excepturi sequi est recusandae veniam consectetur quas placeat magni reprehenderit cupiditate unde fugit voluptates nesciunt aut ea, eos natus, iste ipsa maiores tenetur dolore, officiis nostrum voluptatibus. Corporis, alias saepe perferendis magni delectus repudiandae repellat voluptatibus molestiae incidunt nostrum! Enim mollitia praesentium, itaque minus recusandae at cumque eveniet sit a voluptatibus, tenetur quidem, culpa voluptate quod quaerat eius veritatis! Ea non quia nostrum nobis! Recusandae, culpa. Dolores, numquam, maiores eius corrupti, in voluptatibus nihil facilis perferendis molestiae libero quod recusandae necessitatibus qui veritatis sit corporis suscipit ut. Ducimus aut illum blanditiis quos, reiciendis, animi cupiditate dolorem autem quam magni vel, incidunt perspiciatis doloremque officiis distinctio! A officia eaque rerum officiis praesentium nisi quasi sint aut, architecto, accusantium, debitis modi. Veniam molestias nobis possimus a dolorum, neque esse sed. Perferendis aperiam repudiandae dicta soluta autem consequuntur tenetur suscipit at, optio officia doloremque voluptas, officiis porro ea quidem recusandae. Similique veritatis sapiente voluptates illo molestias dicta temporibus numquam consequatur fuga minima! Dicta reprehenderit molestias tempore velit minus? Omnis quis deleniti, molestiae magnam minus tempora deserunt aut quas nesciunt nam debitis! Minima ut voluptates iure. Porro maiores hic voluptas, cum soluta vero, deserunt voluptatem sapiente vel, beatae ipsa iure quas dignissimos ea cumque aliquid nam eos. Velit, nulla sunt?
"""
]

fruit=['apple','mango','banana']
def home(request):
    return render(request,"index.html",context={'student':student,'text':text,'fruit':fruit})


def contact(request):
    return render(request,"contact.html")

def about(request):
    return render(request,"about.html")
def success_page(request):
    return HttpResponse("this is success page")


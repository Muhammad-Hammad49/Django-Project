from django.db import models

class std(models.Model):
    name=models.CharField(max_length=20)
    age=models.IntegerField()
    email=models.EmailField()
    address=models.CharField(max_length=20)
    # image=models.ImageField()
    #

class game_g(models.Model):
    game_name=models.CharField(max_length=100)
    game_size=models.IntegerField(default=50)
    def __str__(self) -> str:
        return self.game_name
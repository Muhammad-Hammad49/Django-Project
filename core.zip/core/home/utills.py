from home.models import *
def ac():
    print("happy")